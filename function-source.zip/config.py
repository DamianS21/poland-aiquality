STATIONS_HTML_ = 'https://api.gios.gov.pl/pjp-api/rest/station/'
SENSORS_HTML_ = 'https://api.gios.gov.pl/pjp-api/rest/station/sensors/'
DATA_SENSOR_HTML_ = 'https://api.gios.gov.pl/pjp-api/rest/data/getData/'
BQ_TABLE_ID = 'pl-air-quality.prod.stations_sensors_data'